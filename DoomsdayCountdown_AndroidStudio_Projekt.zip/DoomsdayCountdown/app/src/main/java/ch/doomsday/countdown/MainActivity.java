package ch.doomsday.countdown;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int NOTIFICATIONS_REQUEST = 4242;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(6, 9, 17));
        getWindow().setNavigationBarColor(Color.rgb(6, 9, 17));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(6, 9, 17));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        ReminderScheduler.createChannel(this);
        ReminderScheduler.scheduleAll(this);
    }

    private boolean isPermissionGranted() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATIONS_REQUEST) {
            if (isPermissionGranted()) ReminderScheduler.scheduleAll(this);
            webView.evaluateJavascript("window.refreshNativePermission && window.refreshNativePermission();", null);
        }
    }

    private final class NativeBridge {
        @JavascriptInterface
        public String getSettings() {
            return ReminderScheduler.loadSettings(MainActivity.this).toString();
        }

        @JavascriptInterface
        public void saveSettings(String settingsJson) {
            try {
                JSONObject object = new JSONObject(settingsJson);
                ReminderScheduler.storeSettings(MainActivity.this, object);
                ReminderScheduler.scheduleAll(MainActivity.this);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public boolean notificationsGranted() {
            return isPermissionGranted();
        }

        @JavascriptInterface
        public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && !isPermissionGranted()) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATIONS_REQUEST);
                } else {
                    ReminderScheduler.scheduleAll(MainActivity.this);
                    webView.evaluateJavascript("window.refreshNativePermission && window.refreshNativePermission();", null);
                }
            });
        }

        @JavascriptInterface
        public void testNotification() {
            runOnUiThread(() -> {
                if (!isPermissionGranted()) {
                    requestNotifications();
                } else {
                    ReminderScheduler.showNotification(MainActivity.this, "test");
                }
            });
        }
    }
}
