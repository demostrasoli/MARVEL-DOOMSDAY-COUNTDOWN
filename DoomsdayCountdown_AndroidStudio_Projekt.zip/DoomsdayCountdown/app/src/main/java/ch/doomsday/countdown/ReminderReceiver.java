package ch.doomsday.countdown;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        JSONObject config = ReminderScheduler.loadSettings(context);
        if (!config.optBoolean("enabled", false)) return;
        String kind = intent.getStringExtra("kind");
        if (kind == null) return;
        long target = config.optLong("target", ReminderScheduler.DEFAULT_TARGET);
        if (System.currentTimeMillis() > target + 3600000L) return;
        ReminderScheduler.showNotification(context, kind);
        ReminderScheduler.scheduleAll(context);
    }
}
