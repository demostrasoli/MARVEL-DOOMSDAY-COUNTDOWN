package ch.doomsday.countdown;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public final class ReminderScheduler {
    private static final String PREFS = "doomsday_settings";
    private static final String KEY = "config";
    private static final String CHANNEL = "doom_countdown_v1";
    private static final String ACTION = "ch.doomsday.countdown.REMIND.";
    public static final long DEFAULT_TARGET = 1797375600000L; // 16 Dec 2026, 00:00 Europe/Zurich
    private static final TimeZone SWISS = TimeZone.getTimeZone("Europe/Zurich");
    private static final int[] IDS = {100, 107, 103, 101, 110, 199};
    private static final String[] KINDS = {"regular", "7d", "3d", "1d", "1h", "release"};

    private ReminderScheduler() { }

    public static JSONObject loadSettings(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
        if (json != null) {
            try { return new JSONObject(json); } catch (Exception ignored) { }
        }
        JSONObject object = new JSONObject();
        try {
            object.put("enabled", false);
            object.put("frequency", "daily");
            object.put("hour", 9);
            object.put("minute", 0);
            object.put("milestones", true);
            object.put("target", DEFAULT_TARGET);
        } catch (Exception ignored) { }
        return object;
    }

    public static void storeSettings(Context context, JSONObject settings) {
        long target = settings.optLong("target", DEFAULT_TARGET);
        if (target < 1750000000000L || target > 2050000000000L) {
            try { settings.put("target", DEFAULT_TARGET); } catch (Exception ignored) { }
        }
        int hour = Math.max(0, Math.min(23, settings.optInt("hour", 9)));
        int minute = Math.max(0, Math.min(59, settings.optInt("minute", 0)));
        try { settings.put("hour", hour); settings.put("minute", minute); } catch (Exception ignored) { }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, settings.toString()).apply();
    }

    public static void createChannel(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Doomsday Erinnerungen", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Countdown bis zum Schweizer Kinostart und wichtige Meilensteine");
            manager.createNotificationChannel(channel);
        }
    }

    private static PendingIntent pending(Context context, int id, String kind) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION + id);
        intent.putExtra("kind", kind);
        return PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void setAlarm(Context context, int id, String kind, long at) {
        if (at <= System.currentTimeMillis()) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) {
            // Inexact alarm: no special exact-alarm permission required; OS can delay delivery.
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(context, id, kind));
        }
    }

    public static void scheduleAll(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) {
            for (int i = 0; i < IDS.length; i++) {
                PendingIntent p = pending(context, IDS[i], KINDS[i]);
                manager.cancel(p);
                p.cancel();
            }
        }
        JSONObject settings = loadSettings(context);
        boolean enabled = settings.optBoolean("enabled", false);
        long now = System.currentTimeMillis();
        long target = settings.optLong("target", DEFAULT_TARGET);
        if (!enabled || target <= now) return;

        String frequency = settings.optString("frequency", "daily");
        int hour = settings.optInt("hour", 9);
        int minute = settings.optInt("minute", 0);
        long next = nextRegularTime(now, frequency, hour, minute);
        if (next > now && next < target) setAlarm(context, 100, "regular", next);

        if (settings.optBoolean("milestones", true)) {
            setAlarm(context, 107, "7d", target - TimeUnit.DAYS.toMillis(7));
            setAlarm(context, 103, "3d", target - TimeUnit.DAYS.toMillis(3));
            setAlarm(context, 101, "1d", target - TimeUnit.DAYS.toMillis(1));
            setAlarm(context, 110, "1h", target - TimeUnit.HOURS.toMillis(1));
        }
        setAlarm(context, 199, "release", target);
    }

    private static Calendar calendar(long at, int hour, int minute) {
        Calendar cal = Calendar.getInstance(SWISS);
        cal.setTimeInMillis(at);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal;
    }

    private static long nextRegularTime(long now, String frequency, int hour, int minute) {
        if ("off".equals(frequency)) return -1L;
        Calendar next = calendar(now, hour, minute);
        if ("weekly".equals(frequency)) {
            while (next.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY || next.getTimeInMillis() <= now + 1500L) {
                next.add(Calendar.DAY_OF_YEAR, 1);
            }
            return next.getTimeInMillis();
        }
        if ("twice".equals(frequency)) {
            Calendar second = calendar(now, (hour + 12) % 24, minute);
            if (next.getTimeInMillis() <= now + 1500L) next.add(Calendar.DAY_OF_YEAR, 1);
            if (second.getTimeInMillis() <= now + 1500L) second.add(Calendar.DAY_OF_YEAR, 1);
            return Math.min(next.getTimeInMillis(), second.getTimeInMillis());
        }
        if (next.getTimeInMillis() <= now + 1500L) next.add(Calendar.DAY_OF_YEAR, 1);
        return next.getTimeInMillis();
    }

    public static void showNotification(Context context, String kind) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        JSONObject settings = loadSettings(context);
        long target = settings.optLong("target", DEFAULT_TARGET);
        long remain = Math.max(0L, target - System.currentTimeMillis());
        long days = TimeUnit.MILLISECONDS.toDays(remain);
        long hours = TimeUnit.MILLISECONDS.toHours(remain) % 24;
        long minutes = TimeUnit.MILLISECONDS.toMinutes(remain) % 60;
        String message;
        if ("release".equals(kind) || remain == 0) {
            message = "Der Schweizer Kinostart ist da! Viel Spass im Kino.";
        } else {
            message = "Noch " + days + " Tage, " + hours + " Std. und " + minutes + " Min. bis zum Kinostart.";
        }
        if ("7d".equals(kind)) message = "Noch eine Woche! " + message;
        if ("3d".equals(kind)) message = "Noch drei Tage! " + message;
        if ("1d".equals(kind)) message = "Morgen ist es so weit! " + message;
        if ("1h".equals(kind)) message = "Die letzte Stunde! " + message;
        if ("test".equals(kind)) message = "Testalarm funktioniert. " + message;

        Intent launch = new Intent(context, MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open = PendingIntent.getActivity(context, 200, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("DOOMSDAY · Countdown")
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setShowWhen(true)
                .build();
        manager.notify("doom_" + kind, 1, notification);
    }
}
