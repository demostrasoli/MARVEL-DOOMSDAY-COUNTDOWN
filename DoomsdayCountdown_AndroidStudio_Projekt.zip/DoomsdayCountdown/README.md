# DOOMSDAY Countdown · Schweiz 🇨🇭

Eine eigenständige, offlinefähige Android-App (Fan-Projekt) mit animiertem Live-Countdown und lokalen Systembenachrichtigungen für **Avengers: Doomsday**.

## Schweizer Start

**Mittwoch, 16. Dezember 2026**, bestätigt bei Cineman, OutNow und Arena Cinemas.
Quellen: [Cineman](https://www.cineman.ch/movie/2026/AvengersDoomsday/), [OutNow](https://outnow.ch/Movies/2026/Avengers-Doomsday/), [Arena Cinemas](https://www.arena.ch/de/filme?suisa=1021164).

Die App zählt ab Werk bis zum **16.12.2026 um 00:00 Uhr (Schweiz)** herunter. Das ist der *Beginn des offiziellen Kinostarttags*, nicht eine bestätigte Uhrzeit der ersten Aufführung. Im Bereich **Mein Kinotermin** kann man seine konkrete Vorstellungszeit wählen.

## Funktionen

- Countdown mit Tagen, Stunden, Minuten und Sekunden und animierter Fortschrittsanzeige
- Original gestaltete dunkle Oberfläche mit grünem Sci-Fi-Look
- Android-Benachrichtigungen: **wöchentlich, täglich oder zweimal täglich** zur gewählten Uhrzeit (Schweizer Zeitzone)
- Optional vier zusätzliche Erinnerungen **7 Tage, 3 Tage, 1 Tag und 1 Stunde** vorher sowie am Kinostart
- Test-Benachrichtigung, an-/abschaltbare Erinnerungen
- Eigener Kinotermin mit Datum und Uhrzeit; Speicherung über Android SharedPreferences
- Alarme werden nach einem Neustart des Smartphones neu eingerichtet
- Keine Accounts, kein Tracking, keine Netzwerkanfragen, keine Fremdbibliotheken

**Technischer Hinweis:** Android liefert solche Hintergrund-Alarme möglicherweise leicht verzögert aus (Doze/Akkuoptimierung). Die App nutzt absichtlich keine besonders weitgehende Berechtigung für exakte Alarme. Vor allem für die 1-Stunden-Warnung ist die Zustellung daher **nicht sekundengenau garantiert**. Für echte Weckalarme sollte man zusätzlich die System-Uhr-App nutzen.

## Eine APK aus dem Projekt erstellen

### Methode A: Android Studio

1. ZIP-Datei entpacken, den Ordner `DoomsdayCountdown` in **Android Studio** über **Open** öffnen.
2. Android SDK 35 und Gradle 8.9 installieren, falls Android Studio danach fragt. Ein JDK 17 wird benötigt.
3. Unter **Settings → Build, Execution, Deployment → Build Tools → Gradle** ggf. die lokale Gradle-Version 8.9 wählen, falls kein Wrapper vorhanden ist.
4. Menü **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Die installierbare Debug-APK liegt in `app/build/outputs/apk/debug/app-debug.apk`.
6. Die APK auf das Samsung-Smartphone übertragen und installieren. Android fragt gegebenenfalls nach **Unbekannte Apps installieren**. Nach dem ersten Start die Benachrichtigungen aktivieren und freigeben.

### Methode B: GitHub Actions (ohne Android Studio auf deinem Rechner)

Das Projekt enthält `.github/workflows/build-apk.yml`. Lade den **Inhalt des Projektordners** als Repository auf GitHub hoch, öffne **Actions → Build Android APK → Run workflow** und lade nach dem erfolgreichen Lauf unter **Artifacts** die Datei `Doomsday-Countdown-APK` herunter. Darin ist `app-debug.apk` enthalten.

Das `debug`-APK ist installierbar, aber nicht als Play-Store-Release signiert. Ein Play-Store-Release benötigt ein eigenes Signaturzertifikat.

## Vorschau

`app/src/main/assets/index.html` ist die identische UI und läuft auch direkt im Browser. Ohne Android-System sind die Benachrichtigungen nur als Demo dargestellt; das native Java-Projekt liefert die echten lokalen Android-Alarme.

## Technische Daten

- Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9
- Min SDK 26 (Android 8), target SDK 35
- Paket-ID `ch.doomsday.countdown`
- `WebView` für lokale Benutzeroberfläche, Android `AlarmManager`, `BroadcastReceiver` und `NotificationManager`

Dies ist eine inoffizielle Fan-App. Sie steht in keiner Verbindung zu Marvel Studios oder Disney. Die grafische Maske ist eine eigenständige Sci-Fi-Illustration.
